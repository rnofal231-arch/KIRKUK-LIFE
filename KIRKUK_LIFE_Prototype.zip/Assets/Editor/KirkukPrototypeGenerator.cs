using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.IO;

public static class KirkukPrototypeGenerator
{
    [MenuItem("Tools/KIRKUK LIFE/Generate Prototype Scene")]
    public static void Generate()
    {
        Directory.CreateDirectory("Assets/Scenes");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        GameObject root = new GameObject("KIRKUK LIFE - Prototype City");

        Material mat(string name, Color color) {
            var m = new Material(Shader.Find("Standard")); m.name=name; m.color=color; return m;
        }
        var asphalt=mat("Road asphalt",new Color(.12f,.13f,.14f));
        var sand=mat("Sidewalk",new Color(.58f,.53f,.43f));
        var wall=mat("Building plaster",new Color(.72f,.63f,.49f));
        var glass=mat("Shop glass",new Color(.18f,.32f,.38f));
        var green=mat("Player clothes",new Color(.18f,.28f,.22f));
        var carPaint=mat("Car paint",new Color(.55f,.08f,.06f));
        var skin=mat("Pedestrian",new Color(.72f,.48f,.32f));

        void cube(string n, Vector3 pos, Vector3 scale, Material material, Transform parent=null) {
            var g=GameObject.CreatePrimitive(PrimitiveType.Cube); g.name=n; g.transform.SetParent(parent);
            g.transform.position=pos; g.transform.localScale=scale; g.GetComponent<Renderer>().sharedMaterial=material;
        }
        cube("Main asphalt road",new Vector3(0,-.12f,0),new Vector3(14,.2f,100),asphalt,root.transform);
        cube("Left sidewalk",new Vector3(-8,.02f,0),new Vector3(2,.25f,100),sand,root.transform);
        cube("Right sidewalk",new Vector3(8,.02f,0),new Vector3(2,.25f,100),sand,root.transform);
        for(int side=-1;side<=1;side+=2)
        for(int i=0;i<8;i++) {
            float z=-42+i*12;
            cube("Kirkuk street building",new Vector3(side*13,3,z),new Vector3(8,6,9),wall,root.transform);
            cube("Shopfront",new Vector3(side*8.94f,1.5f,z),new Vector3(.08f,2.5f,3),glass,root.transform);
            cube("Roof parapet",new Vector3(side*13,6.2f,z),new Vector3(8,.4f,9),sand,root.transform);
        }
        for(int i=-4;i<=4;i++) cube("Road lane marking",new Vector3(0,.001f,i*10),new Vector3(.16f,.02f,4),sand,root.transform);

        var player=GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name="Civilian Player"; player.transform.position=new Vector3(-3,1,0);
        player.GetComponent<Renderer>().sharedMaterial=green;
        Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        var cc=player.AddComponent<CharacterController>(); cc.height=2; cc.radius=.42f;
        var controller=player.AddComponent<ThirdPersonPlayer>();

        var camObj=new GameObject("Third Person Camera"); var cam=camObj.AddComponent<Camera>();
        cam.tag="MainCamera"; camObj.AddComponent<AudioListener>();
        var orbit=camObj.AddComponent<OrbitCamera>(); orbit.target=player.transform;
        controller.cameraTransform=cam.transform;

        for(int i=0;i<5;i++) {
            var ped=GameObject.CreatePrimitive(PrimitiveType.Capsule); ped.name="Street Pedestrian";
            ped.transform.position=new Vector3((i%2==0)?-7:7,1,-20+i*9);
            ped.transform.localScale=new Vector3(.7f,1,.7f);
            ped.GetComponent<Renderer>().sharedMaterial=skin;
            ped.AddComponent<PedestrianWander>();
        }

        var car=GameObject.CreatePrimitive(PrimitiveType.Cube); car.name="Driveable Sedan";
        car.transform.position=new Vector3(3,.65f,5); car.transform.localScale=new Vector3(2,1,4);
        car.GetComponent<Renderer>().sharedMaterial=carPaint;
        var rb=car.AddComponent<Rigidbody>(); rb.mass=1150;
        var ccCar=car.AddComponent<CarController>();
        var seat=new GameObject("Driver Seat"); seat.transform.SetParent(car.transform);
        seat.transform.localPosition=new Vector3(0,.7f,0); ccCar.seat=seat.transform;

        var inputObj=new GameObject("Mobile Input"); var mobile=inputObj.AddComponent<MobileInput>();
        controller.mobileInput=mobile;
        var interactionObj=new GameObject("Interaction"); var interaction=interactionObj.AddComponent<Interaction>();
        interaction.player=controller;

        var lightObj=new GameObject("Sun"); var light=lightObj.AddComponent<Light>();
        light.type=LightType.Directional; light.intensity=1.15f; light.transform.rotation=Quaternion.Euler(45,-35,0);
        RenderSettings.ambientLight=new Color(.55f,.52f,.47f);
        RenderSettings.skybox=null;
        cam.clearFlags=CameraClearFlags.SolidColor; cam.backgroundColor=new Color(.48f,.68f,.78f);
        cam.fieldOfView=65;

        // Basic on-screen action buttons; joystick UI can be added in the next iteration.
        var canvasObj=new GameObject("Mobile HUD",typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));
        var canvas=canvasObj.GetComponent<Canvas>(); canvas.renderMode=RenderMode.ScreenSpaceOverlay;
        var scaler=canvasObj.GetComponent<CanvasScaler>(); scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution=new Vector2(1920,1080);
        var eventObj=new GameObject("EventSystem",typeof(UnityEngine.EventSystems.EventSystem),typeof(UnityEngine.EventSystems.StandaloneInputModule));
        MakeButton(canvas.transform,"UP",new Vector2(-260,220),new Vector2(110,85),mobile,null,TouchButton.ActionType.Forward);
        MakeButton(canvas.transform,"DOWN",new Vector2(-260,35),new Vector2(110,85),mobile,null,TouchButton.ActionType.Back);
        MakeButton(canvas.transform,"LEFT",new Vector2(-380,125),new Vector2(110,85),mobile,null,TouchButton.ActionType.Left);
        MakeButton(canvas.transform,"RIGHT",new Vector2(-140,125),new Vector2(110,85),mobile,null,TouchButton.ActionType.Right);
        MakeButton(canvas.transform,"RUN",new Vector2(-180,245),new Vector2(150,80),mobile,null,TouchButton.ActionType.Run);
        MakeButton(canvas.transform,"ENTER / EXIT",new Vector2(-180,145),new Vector2(220,80),mobile,interaction,TouchButton.ActionType.Interact);

        EditorSceneManager.SaveScene(scene,"Assets/Scenes/KirkukPrototype.unity");
        Selection.activeObject=root;
        EditorUtility.DisplayDialog("KIRKUK LIFE","Prototype city scene created. Open Assets/Scenes/KirkukPrototype.unity and press Play.","OK");
    }

    static void MakeButton(Transform parent,string label,Vector2 pos,Vector2 size,MobileInput input,Interaction interaction,TouchButton.ActionType type)
    {
        var go=new GameObject(label,typeof(RectTransform),typeof(Image),typeof(Button),typeof(TouchButton));
        go.transform.SetParent(parent,false);
        var rt=go.GetComponent<RectTransform>(); rt.anchorMin=rt.anchorMax=new Vector2(1,0);
        rt.pivot=new Vector2(1,0); rt.anchoredPosition=pos; rt.sizeDelta=size;
        go.GetComponent<Image>().color=new Color(.05f,.07f,.08f,.72f);
        var t=go.GetComponent<TouchButton>(); t.input=input; t.interaction=interaction; t.action=type;
        var textGo=new GameObject("Label",typeof(RectTransform),typeof(Text));
        textGo.transform.SetParent(go.transform,false);
        var txt=textGo.GetComponent<Text>(); txt.text=label; txt.alignment=TextAnchor.MiddleCenter;
        txt.font=Resources.GetBuiltinResource<Font>("Arial.ttf"); txt.color=Color.white; txt.fontSize=25;
        var tr=textGo.GetComponent<RectTransform>(); tr.anchorMin=Vector2.zero; tr.anchorMax=Vector2.one; tr.offsetMin=tr.offsetMax=Vector2.zero;
    }
}
