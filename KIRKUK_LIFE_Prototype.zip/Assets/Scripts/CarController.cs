using UnityEngine;

public class CarController : MonoBehaviour
{
    public float acceleration = 11f, maxSpeed = 22f, turnSpeed = 75f;
    public Transform seat;
    public AudioSource engineAudio;
    Rigidbody body;
    float throttle, steering;
    bool occupied;
    ThirdPersonPlayer driver;
    MobileInput mobile;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        if (!body) body = gameObject.AddComponent<Rigidbody>();
        body.mass = 1150; body.drag = 0.35f; body.angularDrag = 2.5f;
        mobile = FindObjectOfType<MobileInput>();
    }

    void Update()
    {
        if (!occupied) return;
        throttle = Input.GetAxis("Vertical");
        steering = Input.GetAxis("Horizontal");
        if (mobile && mobile.Move != Vector2.zero)
        { throttle = mobile.Move.y; steering = mobile.Move.x; }
        if (engineAudio) engineAudio.pitch = 0.8f + Mathf.Abs(body.velocity.magnitude) / maxSpeed * 0.7f;
    }

    void FixedUpdate()
    {
        if (!occupied) return;
        if (body.velocity.magnitude < maxSpeed)
            body.AddForce(transform.forward * throttle * acceleration, ForceMode.Acceleration);
        float steerFactor = Mathf.Clamp01(body.velocity.magnitude / 3f);
        body.MoveRotation(body.rotation * Quaternion.Euler(0, steering * turnSpeed * steerFactor * Time.fixedDeltaTime, 0));
    }

    public void ToggleDrive(ThirdPersonPlayer player)
    {
        if (!occupied)
        {
            occupied = true; driver = player; driver.IsDriving = true;
            if (seat) driver.transform.position = seat.position;
            driver.gameObject.SetActive(false);
        }
        else if (driver == player)
        {
            occupied = false; driver.gameObject.SetActive(true);
            driver.IsDriving = false;
            driver.transform.position = transform.position + transform.right * 2f + Vector3.up * 0.2f;
            driver = null; throttle = steering = 0;
        }
    }

    public bool IsOccupied => occupied;
}
