using UnityEngine;

public class PedestrianWander : MonoBehaviour
{
    public float speed = 1.25f, radius = 7f;
    Vector3 destination;
    void Start() { PickDestination(); }
    void Update()
    {
        Vector3 flat = destination - transform.position; flat.y = 0;
        if (flat.magnitude < 0.5f) { PickDestination(); return; }
        Vector3 dir = flat.normalized;
        transform.position += dir * speed * Time.deltaTime;
        transform.rotation = Quaternion.Slerp(transform.rotation,
            Quaternion.LookRotation(dir), 5f * Time.deltaTime);
    }
    void PickDestination()
    {
        Vector2 p = Random.insideUnitCircle * radius;
        destination = transform.position + new Vector3(p.x, 0, p.y);
    }
}
