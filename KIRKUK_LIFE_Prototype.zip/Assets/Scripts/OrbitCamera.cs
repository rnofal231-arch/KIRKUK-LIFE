using UnityEngine;

public class OrbitCamera : MonoBehaviour
{
    public Transform target;
    public float distance = 5f, height = 2.2f, sensitivity = 0.15f;
    float yaw;
    Vector2 lastTouch;
    int lookFinger = -1;

    void LateUpdate()
    {
        if (!target) return;
        if (Input.GetMouseButton(1)) yaw += Input.GetAxis("Mouse X") * 4f;
        for (int i = 0; i < Input.touchCount; i++)
        {
            Touch t = Input.GetTouch(i);
            if (t.position.x > Screen.width * 0.48f)
            {
                if (t.phase == TouchPhase.Began) { lookFinger = t.fingerId; lastTouch = t.position; }
                else if (t.fingerId == lookFinger && t.phase == TouchPhase.Moved)
                { yaw += t.deltaPosition.x * sensitivity; }
                else if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled)
                    if (t.fingerId == lookFinger) lookFinger = -1;
            }
        }
        Quaternion rotation = Quaternion.Euler(12f, yaw, 0);
        Vector3 focus = target.position + Vector3.up * height;
        transform.position = focus - rotation * Vector3.forward * distance;
        transform.rotation = rotation;
    }
}
