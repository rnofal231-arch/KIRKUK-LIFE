using UnityEngine;

public class MobileInput : MonoBehaviour
{
    public Vector2 Move { get; private set; }
    public bool Run { get; private set; }
    public void SetMoveX(float value) { Move = new Vector2(value, Move.y); }
    public void SetMoveY(float value) { Move = new Vector2(Move.x, value); }
    public void SetRun(bool value) { Run = value; }
    public void ClearMove() { Move = Vector2.zero; }
}
