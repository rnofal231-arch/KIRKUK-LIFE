using UnityEngine;

public class Interaction : MonoBehaviour
{
    public ThirdPersonPlayer player;
    public float range = 4f;
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E)) TryUse();
    }
    public void TryUse()
    {
        if (!player) player = FindObjectOfType<ThirdPersonPlayer>();
        if (!player) return;
        CarController nearest = null;
        float best = range;
        foreach (var car in FindObjectsOfType<CarController>())
        {
            float d = Vector3.Distance(player.transform.position, car.transform.position);
            if (d < best) { best = d; nearest = car; }
        }
        if (nearest) nearest.ToggleDrive(player);
    }
}
