using UnityEngine;
using UnityEngine.EventSystems;

public class TouchButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public enum ActionType { Run, Interact, Forward, Back, Left, Right }
    public ActionType action;
    public MobileInput input;
    public Interaction interaction;

    public void OnPointerDown(PointerEventData eventData)
    {
        if (!input && action != ActionType.Interact) return;
        switch (action)
        {
            case ActionType.Run: input.SetRun(true); break;
            case ActionType.Interact: if (interaction) interaction.TryUse(); break;
            case ActionType.Forward: input.SetMoveY(1); break;
            case ActionType.Back: input.SetMoveY(-1); break;
            case ActionType.Left: input.SetMoveX(-1); break;
            case ActionType.Right: input.SetMoveX(1); break;
        }
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (!input) return;
        switch (action)
        {
            case ActionType.Run: input.SetRun(false); break;
            case ActionType.Forward:
            case ActionType.Back: input.SetMoveY(0); break;
            case ActionType.Left:
            case ActionType.Right: input.SetMoveX(0); break;
        }
    }
}
