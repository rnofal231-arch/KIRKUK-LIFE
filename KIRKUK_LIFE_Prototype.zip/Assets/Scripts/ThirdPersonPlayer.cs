using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class ThirdPersonPlayer : MonoBehaviour
{
    public float walkSpeed = 4f;
    public float runSpeed = 6.5f;
    public float gravity = -20f;
    public Transform cameraTransform;
    public MobileInput mobileInput;
    CharacterController controller;
    Vector3 verticalVelocity;
    public bool IsDriving { get; set; }

    void Awake() { controller = GetComponent<CharacterController>(); }

    void Update()
    {
        if (IsDriving) return;
        Vector2 input = mobileInput ? mobileInput.Move : new Vector2(
            Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));

        Vector3 forward = cameraTransform ? cameraTransform.forward : Vector3.forward;
        Vector3 right = cameraTransform ? cameraTransform.right : Vector3.right;
        forward.y = 0; right.y = 0; forward.Normalize(); right.Normalize();
        Vector3 move = forward * input.y + right * input.x;
        if (move.sqrMagnitude > 1) move.Normalize();

        float speed = (mobileInput && mobileInput.Run) || Input.GetKey(KeyCode.LeftShift)
            ? runSpeed : walkSpeed;

        if (move.sqrMagnitude > 0.01f)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation,
                Quaternion.LookRotation(move), 12f * Time.deltaTime);
        }

        if (controller.isGrounded && verticalVelocity.y < 0) verticalVelocity.y = -2f;
        verticalVelocity.y += gravity * Time.deltaTime;
        controller.Move((move * speed + verticalVelocity) * Time.deltaTime);
    }
}
