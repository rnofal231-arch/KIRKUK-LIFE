using UnityEngine;

public class TrafficCar : MonoBehaviour
{
    public float speed = 4f, distance = 55f;
    Vector3 start;
    void Start() { start = transform.position; }
    void Update()
    {
        transform.position += transform.forward * speed * Time.deltaTime;
        if (Vector3.Distance(start, transform.position) > distance)
            transform.position = start;
    }
}
